#!/usr/bin/env bash
set -u
export PATH=/usr/local/cuda/bin:/usr/local/bin:$PATH
ROOT=/study
RAW=$ROOT/raw
BIN=$ROOT/llama.cpp/build-cuda/bin/llama-bench
NAME=$1
MODEL=$2
DEPTH=$3
KV=$4
B=$5
UB=$6
mkdir -p "$RAW/bench" "$RAW/diagnostics" "$RAW/meta"
OUT="$RAW/bench/$NAME.stdout.json"
ERR="$RAW/bench/$NAME.stderr.log"
META="$RAW/meta/$NAME.meta.txt"
SAMPLE="$RAW/diagnostics/$NAME.nvidia-smi.csv"
RAM="$RAW/diagnostics/$NAME.ram.csv"
CGROUP="$RAW/diagnostics/$NAME.cgroup-memory.csv"
START=$(date -u +%Y-%m-%dT%H:%M:%SZ)
printf 'name=%s\nstart_utc=%s\n' "$NAME" "$START" > "$META"
printf 'argv=' >> "$META"
printf '%q ' "$BIN" -v -r 1 -p 0 -n 128 -ngl 99 -t 8 -b "$B" -ub "$UB" -ctk "$KV" -ctv "$KV" -fa auto --no-warmup -d "$DEPTH" -o json -m "$MODEL" >> "$META"
printf '\n' >> "$META"
nvidia-smi --query-gpu=timestamp,memory.used,utilization.gpu,power.draw,temperature.gpu --format=csv,noheader,nounits --loop=1 > "$SAMPLE" 2> "$RAW/diagnostics/$NAME.nvidia-smi.stderr.log" & GP=$!
(while :; do printf '%s,' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"; free -b | awk '/^Mem:/ {print $2 "," $3 "," $4}'; sleep 5; done) > "$RAM" & RP=$!
(while [ -r /sys/fs/cgroup/memory.current ]; do printf '%s,' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"; cat /sys/fs/cgroup/memory.current; sleep 2; done) > "$CGROUP" & CP=$!
sleep 0.25
/usr/bin/time -f 'wall_seconds=%e\nuser_seconds=%U\nsystem_seconds=%S\nmaxrss_kb=%M' -o "$RAW/meta/$NAME.wall-time.txt" "$BIN" -v -r 1 -p 0 -n 128 -ngl 99 -t 8 -b "$B" -ub "$UB" -ctk "$KV" -ctv "$KV" -fa auto --no-warmup -d "$DEPTH" -o json -m "$MODEL" > "$OUT" 2> "$ERR"
RC=$?
kill "$GP" "$RP" "$CP" 2>/dev/null || true
wait "$GP" "$RP" "$CP" 2>/dev/null || true
END=$(date -u +%Y-%m-%dT%H:%M:%SZ)
printf 'exit_code=%s\nend_utc=%s\n' "$RC" "$END" >> "$META"
python3 - "$SAMPLE" "$OUT" "$ERR" "$META" "$RAM" "$CGROUP" <<'PY' >> "$META"
import csv, json, pathlib, re, sys
sample, out, err, meta, ram, cgroup=map(pathlib.Path,sys.argv[1:])
vals=[]
for row in csv.reader(sample.open()):
    if len(row)>1:
        try: vals.append(float(row[1].strip()))
        except ValueError: pass
print(f'peak_vram_mib={max(vals) if vals else "unavailable"}')
try:
    data=json.loads(out.read_text())
    rows=data if isinstance(data,list) else [data]
    rates=[(r.get('avg_ts'),r.get('samples_ts'),r.get('n_depth'),r.get('type_k'),r.get('n_batch'),r.get('n_ubatch')) for r in rows if isinstance(r,dict)]
    print(f'throughput_tok_s_and_samples={rates!r}')
except Exception as e: print(f'json_parse_error={e!r}')
text=err.read_text(errors='replace')
kv=[line.strip() for line in text.splitlines() if re.search(r'KV.*buffer size|buffer size.*KV|KV.*size',line,re.I)]
print('kv_log_lines=' + repr(kv))
buffers=[float(m.group(1)) for line in text.splitlines() if (m:=re.search(r'CUDA\d+ KV buffer size\s*=\s*([0-9.]+) MiB',line))]
depth=0
try:
    data=json.loads(out.read_text()); rows=data if isinstance(data,list) else [data]
    depth=int(next(r.get('n_depth',0) for r in rows if isinstance(r,dict)))
except Exception: pass
total_mib=sum(buffers)
print(f'kv_buffer_total_mib={total_mib}')
print(f'kv_bytes_per_requested_depth_token={(total_mib*1024*1024/depth) if depth else "unavailable"}')
host=[]
for row in csv.reader(ram.open()):
    if len(row)>2:
        try: host.append(int(row[2]))
        except ValueError: pass
cg=[]
for row in csv.reader(cgroup.open()):
    if len(row)>1:
        try: cg.append(int(row[1]))
        except ValueError: pass
print(f'peak_host_ram_used_bytes={max(host) if host else "unavailable"}')
print(f'peak_cgroup_memory_current_bytes={max(cg) if cg else "unavailable"}')
PY
printf 'run_complete name=%s exit=%s start=%s end=%s\n' "$NAME" "$RC" "$START" "$END"
exit 0
